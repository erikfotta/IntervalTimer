//
//  ViewController.swift
//  IntervalTimer
//
//  Created by Erik Fotta on 5/20/20.
//  Copyright © 2020 Erik Fotta. All rights reserved.
//

import Foundation
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    
    var timeSet: Double = 30.0
    var isRunning: Bool = false
    
    let lGray = UIColor(rgb: 0xf9fbfb)
    let blue = UIColor(rgb: 0x66d9ee)
    let orange = UIColor(rgb: 0xffb36a)
    let dGray = UIColor(rgb: 0x3a4a4d)
    let white = UIColor(rgb: 0xffffff)
    
    let defaults = UserDefaults.standard
    var workoutsFile: [Exercise] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.barStyle = .black
        navigationController?.navigationBar.barTintColor = blue
        navigationController?.navigationBar.tintColor = white
        
        defaults.set(workoutsFile, forKey: "workout")
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if let workoutsData = defaults.array(forKey: "workout") as? [Exercise] {
            workoutsFile = workoutsData
        }
    }

    @IBAction func buttonPressed(_ sender: Any) {
        if isRunning {
            isRunning = false
            return }
        
        label.text = "\(timeSet)"
        countDown(time: timeSet)
    }
    
    func countDown(time: Double) {
        isRunning = true
        var timeRemaining: Double = time
        _ = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { timer in
            if !self.isRunning { timer.invalidate() }
            timeRemaining -= 0.1
            // String formatter borrowed, see sources
            self.label.text = String(format: "%.1f", timeRemaining)
            
            if timeRemaining <= 0 {
                print("Done")
                timer.invalidate()
                self.isRunning = false
                self.label.text = "0.0"
            }
        }
    }
    
    @IBAction func testButton(_ sender: Any) {
        print(workoutsFile)
    }
    
    
}

extension UIColor {
   convenience init(red: Int, green: Int, blue: Int) {
       assert(red >= 0 && red <= 255, "Invalid red component")
       assert(green >= 0 && green <= 255, "Invalid green component")
       assert(blue >= 0 && blue <= 255, "Invalid blue component")

       self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
   }

   convenience init(rgb: Int) {
       self.init(
           red: (rgb >> 16) & 0xFF,
           green: (rgb >> 8) & 0xFF,
           blue: rgb & 0xFF
       )
   }
}
