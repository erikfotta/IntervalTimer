//
//  BuildCell.swift
//  IntervalTimer
//
//  Created by Erik Fotta on 5/27/20.
//  Copyright © 2020 Erik Fotta. All rights reserved.
//

import UIKit

class BuildCell: UITableViewCell, UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0 {
            return 10
        } else {
            return 60
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0 {
            return pickerPreSets[0][row]
        } else {
            return pickerPreSets[1][row]
        }
    }
    

    let lGray = UIColor(rgb: 0xf9fbfb)
    let blue = UIColor(rgb: 0x66d9ee)
    let orange = UIColor(rgb: 0xffb36a)
    let dGray = UIColor(rgb: 0x3a4a4d)
    let white = UIColor(rgb: 0xffffff)
    
    var pickerPreSets: [[String]] = [["0","1","2","3","4","5","6","7","8","9"], ["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59"]]
    
    @IBOutlet weak var exerciseTitle: UITextField!
    @IBOutlet weak var onPicker: UIPickerView!
    @IBOutlet weak var restPicker: UIPickerView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        contentView.backgroundColor = lGray
        self.onPicker.delegate = self
        self.onPicker.dataSource = self
        self.restPicker.delegate = self
        self.restPicker.dataSource = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
