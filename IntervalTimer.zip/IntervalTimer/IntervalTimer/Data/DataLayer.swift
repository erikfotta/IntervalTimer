//
//  DataLayer.swift
//  IntervalTimer
//
//  Created by Erik Fotta on 5/20/20.
//  Copyright © 2020 Erik Fotta. All rights reserved.
//

import Foundation
