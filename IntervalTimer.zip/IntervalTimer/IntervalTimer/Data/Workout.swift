//
//  Workout.swift
//  IntervalTimer
//
//  Created by Erik Fotta on 5/20/20.
//  Copyright © 2020 Erik Fotta. All rights reserved.
//

import Foundation
import UIKit

let defaults = UserDefaults.standard

struct Workout: Codable {
    var workout: [Exercise] {
        didSet {
            print("this is doing things")
            defaults.set(workout, forKey: "workout")
        }
    }
}
