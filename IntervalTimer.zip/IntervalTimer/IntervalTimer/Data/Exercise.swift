//
//  Exercise.swift
//  IntervalTimer
//
//  Created by Erik Fotta on 5/20/20.
//  Copyright © 2020 Erik Fotta. All rights reserved.
//

import Foundation
import UIKit

struct Exercise: Codable {
    var name: String {
        didSet {
            defaults.set(name, forKey: "name")
        }
    }
    
    var activeTimeMin: Int {
        didSet {
            defaults.set(activeTimeMin, forKey: "activeTimeMin")
        }
    }
    
    var activeTimeSec: Int {
        didSet {
            defaults.set(activeTimeSec, forKey: "activeTimeSec")
        }
    }
    
    var restTimeMin: Int {
        didSet {
            defaults.set(restTimeMin, forKey: "restTimeMin")
        }
    }
    
    var restTimeSec: Int {
        didSet {
            defaults.set(restTimeSec, forKey: "restTimeSec")
        }
    }
    
}
