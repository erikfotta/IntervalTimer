//
//  WorkoutCell.swift
//  IntervalTimer
//
//  Created by Erik Fotta on 6/1/20.
//  Copyright © 2020 Erik Fotta. All rights reserved.
//

import UIKit

class WorkoutCell: UITableViewCell {

    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var onCountdown: UILabel!
    @IBOutlet weak var restCountdown: UILabel!
    
    
    let lGray = UIColor(rgb: 0xf9fbfb)
    let blue = UIColor(rgb: 0x66d9ee)
    let orange = UIColor(rgb: 0xffb36a)
    let dGray = UIColor(rgb: 0x3a4a4d)
    let white = UIColor(rgb: 0xffffff)
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
