#  Sources

## Property Observers
https://nshipster.com/swift-property-observers/
https://www.hackingwithswift.com/read/8/5/property-observers-didset

## Timer
https://www.hackingwithswift.com/articles/117/the-ultimate-guide-to-timer

## String Formatter
https://stackoverflow.com/questions/27338573/rounding-a-double-value-to-x-number-of-decimal-places-in-swift

## UIPicker 
https://codewithchris.com/uipickerview-example/

## Alert Reminders
https://www.google.com/search?sxsrf=ALeKk00nPO4EkKjVbsupytZXB6gVAbdsGA%3A1590635514184&ei=-ivPXu7rCq6pytMPqOSP4A8&q=how+to+add+actions+to+alerts+in+xcode&oq=how+to+add+actions+to+alerts+in+xcode&gs_lcp=CgZwc3ktYWIQAzoECAAQRzoECCEQClDjEFiZJWDzJ2gCcAJ4AYABpwKIAaoPkgEGMTAuMy4zmAEAoAEBqgEHZ3dzLXdpeg&sclient=psy-ab&ved=0ahUKEwju0KiGy9XpAhWulHIEHSjyA_wQ4dUDCAw&uact=5#kpvalbx=_bi7PXsOnFuGHytMPwJGU8Aw31

## Struct Storage
https://elmland.blog/2018/12/17/save-load-structs-userdefaults/


