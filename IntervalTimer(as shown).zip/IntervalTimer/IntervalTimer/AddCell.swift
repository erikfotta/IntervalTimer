//
//  AddCell.swift
//  IntervalTimer
//
//  Created by Erik Fotta on 5/27/20.
//  Copyright © 2020 Erik Fotta. All rights reserved.
//

import UIKit

class AddCell: UITableViewCell {
    
    let lGray = UIColor(rgb: 0xf9fbfb)
    let blue = UIColor(rgb: 0x66d9ee)
    let orange = UIColor(rgb: 0xffb36a)
    let dGray = UIColor(rgb: 0x3a4a4d)
    let white = UIColor(rgb: 0xffffff)
    
    override func awakeFromNib() {
        super.awakeFromNib()
        contentView.backgroundColor = orange
        }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        

    }

}
