//
//  ViewController.swift
//  IntervalTimer
//
//  Created by Erik Fotta on 5/20/20.
//  Copyright © 2020 Erik Fotta. All rights reserved.
//

import Foundation
import UIKit

class ViewController: UIViewController, UITableViewDataSource {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    var timeSet: Double = 30.0
    var isRunning: Bool = false
    
    let lGray = UIColor(rgb: 0xf9fbfb)
    let blue = UIColor(rgb: 0x66d9ee)
    let orange = UIColor(rgb: 0xffb36a)
    let dGray = UIColor(rgb: 0x3a4a4d)
    let white = UIColor(rgb: 0xffffff)
    
    let defaults = UserDefaults.standard
    var workoutFile: [Workout] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.barStyle = .black
        navigationController?.navigationBar.barTintColor = blue
        navigationController?.navigationBar.tintColor = white
        label.textColor = blue
        startButton.tintColor = orange
        startButton.backgroundColor = lGray
        startButton.layer.cornerRadius = 10
        
        tableView.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        workoutFile = defaults.structArrayData(Workout.self, forKey: "workout")
        isRunning = false
        
        tableView.reloadData()
    }
    
    @IBAction func playPressed(_ sender: Any) {
        if isRunning {
            isRunning = false
        } else {
            isRunning = true
            tableView.reloadData()
        }
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if workoutFile.count == 0 {
            return 0
        } else {
            return workoutFile[workoutFile.count-1].workout.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "workoutCell", for: indexPath)
        if let workoutCell = cell as? WorkoutCell {
            workoutCell.title.text = workoutFile[workoutFile.count-1].workout[indexPath.row].name
            let onTimeMin = workoutFile[workoutFile.count-1].workout[indexPath.row].activeTimeMin
            var onTimeSec: Int = Int(workoutFile[workoutFile.count-1].workout[indexPath.row].activeTimeSec)!
            let restTimeMin = workoutFile[workoutFile.count-1].workout[indexPath.row].restTimeMin
            var restTimeSec: Int = Int(workoutFile[workoutFile.count-1].workout[indexPath.row].restTimeSec)!
            workoutCell.onCountdown.text = "\(onTimeMin):\(onTimeSec)"
            workoutCell.restCountdown.text = "\(restTimeMin):\(restTimeSec)"
            
            // This stroke inducing (well not yet but when I tried to do the whole thing it was) block is the baby of rest of the time organizing, which I will not be touching at the moment. For another day, specifically the summer where I have all the time in the world
            if indexPath.row == 0 {
                if isRunning {
                    countDown(time: (onTimeSec + (onTimeMin*60)), outputSecLabel: workoutCell.onCountdown)
                } else {}
            } else {}
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 160
    }

    func countDown(time: Int, outputSecLabel: UILabel) {
        isRunning = true
        var timeRemaining: Int = time
        _ = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            if !self.isRunning { timer.invalidate() }
            timeRemaining -= 1
            outputSecLabel.text = String(timeRemaining)
            
            if timeRemaining <= 0 {
                print("Done")
                timer.invalidate()
                self.isRunning = false
                self.label.text = "0.0"
            }
        }
    }
}

extension UIColor {
   convenience init(red: Int, green: Int, blue: Int) {
       assert(red >= 0 && red <= 255, "Invalid red component")
       assert(green >= 0 && green <= 255, "Invalid green component")
       assert(blue >= 0 && blue <= 255, "Invalid blue component")

       self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
   }

   convenience init(rgb: Int) {
       self.init(
           red: (rgb >> 16) & 0xFF,
           green: (rgb >> 8) & 0xFF,
           blue: rgb & 0xFF
       )
   }
}
