//
//  BuildTableController.swift
//  IntervalTimer
//
//  Created by Erik Fotta on 5/27/20.
//  Copyright © 2020 Erik Fotta. All rights reserved.
//
import Foundation
import UIKit

class BuildTableController: UITableViewController {

    // Global Vars
    var numberOfExcercises: Int = 1
    @IBOutlet var secTableView: UITableView!
    
    let defaults = UserDefaults.standard
    let lGray = UIColor(rgb: 0xf9fbfb)
    let blue = UIColor(rgb: 0x66d9ee)
    let orange = UIColor(rgb: 0xffb36a)
    let dGray = UIColor(rgb: 0x3a4a4d)
    let white = UIColor(rgb: 0xffffff)
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return numberOfExcercises
        } else {
            return 1
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let buildCell = tableView.dequeueReusableCell(withIdentifier: "BuildCell", for: indexPath)
            return buildCell
        } else {
            let addCell = tableView.dequeueReusableCell(withIdentifier: "AddCell", for: indexPath)
            return addCell
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 200
        } else {
            return 60
        }
    }
    
    override func tableView(_ tableView: UITableView, didHighlightRowAt indexPath: IndexPath) {
        if indexPath.section == 1 {
            numberOfExcercises += 1
            tableView.reloadData()
        } else {}
    }

    @IBAction func donePressed(_ sender: Any) {
        let alertController = UIAlertController(title: "Complete Workout", message:
            "Do you wish to proceed?", preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (action) in alertController.dismiss(animated: true, completion: nil)
        }))
        
        alertController.addAction(UIAlertAction(title: "Finish", style: .default, handler: { (action) in alertController.dismiss(animated: true, completion: nil)
            self.tableView.reloadData()
            
            var sessionFile: [Exercise] = []

            var workoutFile = self.defaults.structArrayData(Workout.self, forKey: "workout")
            
            for amount in 0...(self.numberOfExcercises - 1) {
                let cell: BuildCell = self.tableView(self.secTableView, cellForRowAt: IndexPath.init(row: amount, section: 0)) as! BuildCell
                let title = cell.exerciseTitle.text ?? "Exercise"
                let onTimeMin: Int = cell.onPicker.selectedRow(inComponent: 0)
                let onTimeSec: Int = cell.onPicker.selectedRow(inComponent: 1)
                let restTimeMin: Int = cell.restPicker.selectedRow(inComponent: 0)
                let  restTimeSec: Int = cell.restPicker.selectedRow(inComponent: 1)
                let newOnTimeSec = self.timeFix(time: onTimeSec)
                let newRestTimeSec = self.timeFix(time: restTimeSec)
                
                let exercise: Exercise = Exercise(name: title, activeTimeMin: onTimeMin, activeTimeSec: newOnTimeSec, restTimeMin: restTimeMin, restTimeSec: newRestTimeSec)

                sessionFile.append(exercise)
            }
            let session: Workout = Workout(workout: sessionFile)
            workoutFile.append(session)
            
            self.defaults.setStructArray(workoutFile, forKey: "workout")
            
            if let mainViewController = self.navigationController?.viewControllers.first {
                self.navigationController?.popToViewController(mainViewController, animated: true)
            }
        }))

        self.present(alertController, animated: true, completion: nil)
    }
    
    func timeFix(time: Int) -> String {
        if time <= 9 {
            return "0\(time)"
        } else {
            return "\(time)"
        }
    }
}



// Stuff to allow me to store arrays of structs to user defaults. This is taken from here: https://elmland.blog/2018/12/17/save-load-structs-userdefaults/
// I know I shouldn't take this much code, but I've been struggling with this for a few days and I'm out of time so sorry, but oh well. If it helps I understand it to a degree

extension UserDefaults {
    open func setStruct<T: Codable>(_ value: T?, forKey defaultName: String){
        let data = try? JSONEncoder().encode(value)
        set(data, forKey: defaultName)
    }
    
    open func structData<T>(_ type: T.Type, forKey defaultName: String) -> T? where T : Decodable {
        guard let encodedData = data(forKey: defaultName) else {
            return nil
        }
        
        return try! JSONDecoder().decode(type, from: encodedData)
    }
    
    open func setStructArray<T: Codable>(_ value: [T], forKey defaultName: String){
        let data = value.map { try? JSONEncoder().encode($0) }
        
        set(data, forKey: defaultName)
    }
    
    open func structArrayData<T>(_ type: T.Type, forKey defaultName: String) -> [T] where T : Decodable {
        guard let encodedData = array(forKey: defaultName) as? [Data] else {
            return []
        }
        
        return encodedData.map { try! JSONDecoder().decode(type, from: $0) }
    }
}
    
    
    
    
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
